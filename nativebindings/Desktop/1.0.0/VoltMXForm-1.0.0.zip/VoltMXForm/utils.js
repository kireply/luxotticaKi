function newResult() {
    return {
        error: undefined,
        value: undefined
    }
}

module.exports = { newResult }